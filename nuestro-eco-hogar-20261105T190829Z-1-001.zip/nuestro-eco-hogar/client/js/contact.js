

const formContacto = document.getElementById("form-contacto");
const estadoContacto = document.getElementById("estado-contacto");

formContacto.addEventListener("submit", async (e) => {
  e.preventDefault();

  const datos = {
    nombre: document.getElementById("nombre").value.trim(),
    email: document.getElementById("email").value.trim(),
    tipo: document.getElementById("tipo").value,
    mensaje: document.getElementById("mensaje").value.trim(),
  };

  estadoContacto.textContent = "Enviando…";
  estadoContacto.className = "estado-contacto";

  try {
    const respuesta = await fetch(`${API_BASE_URL}/contacto`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(datos),
    });

    const data = await respuesta.json();

    if (!data.exito) throw new Error(data.mensaje || "No se pudo enviar el mensaje");

    estadoContacto.textContent = data.mensaje;
    estadoContacto.className = "estado-contacto ok";
    formContacto.reset();
  } catch (error) {
    estadoContacto.textContent =
      "No pudimos enviar tu mensaje. Verifica los campos o intenta más tarde.";
    estadoContacto.className = "estado-contacto error";
    console.error(error);
  }
});
