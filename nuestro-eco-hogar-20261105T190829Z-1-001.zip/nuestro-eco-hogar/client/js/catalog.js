

const grid = document.getElementById("grid-contaminantes");
const estadoCatalogo = document.getElementById("estado-catalogo");
const formBusqueda = document.getElementById("form-busqueda");
const inputBusqueda = document.getElementById("input-busqueda");
const btnLimpiar = document.getElementById("btn-limpiar");

const modal = document.getElementById("modal-detalle");
const modalContenido = document.getElementById("modal-contenido");
const modalCerrar = document.getElementById("modal-cerrar");


let contaminantesActuales = [];

function claseNivel(nivel) {
  if (nivel === "Alto") return "nivel-alto";
  if (nivel === "Bajo") return "nivel-bajo";
  return "nivel-medio";
}

function crearTarjeta(contaminante) {
  const tarjeta = document.createElement("button");
  tarjeta.type = "button";
  tarjeta.className = "tarjeta";
  tarjeta.setAttribute("data-id", contaminante._id);

  tarjeta.innerHTML = `
    <div class="tarjeta-cabecera">
      <h3>${contaminante.nombre}</h3>
      <span class="categoria-pill">${contaminante.categoria}</span>
    </div>
    <p class="tarjeta-descripcion">${contaminante.descripcion}</p>
    <span class="sello ${claseNivel(contaminante.nivelPreocupacion)}">
      Preocupación ${contaminante.nivelPreocupacion || "Media"}
    </span>
  `;

  tarjeta.addEventListener("click", () => abrirDetalle(contaminante._id));

  return tarjeta;
}

function renderContaminantes(lista) {
  contaminantesActuales = lista;
  grid.innerHTML = "";

  if (!lista || lista.length === 0) {
    grid.innerHTML = `<p class="estado-vacio">No encontramos contaminantes que coincidan con tu búsqueda. Prueba con otro término o revisa las categorías disponibles (microplásticos, ftalatos, bisfenoles, residuos farmacéuticos, pesticidas, PFAS).</p>`;
    return;
  }

  const fragmento = document.createDocumentFragment();
  lista.forEach((c) => fragmento.appendChild(crearTarjeta(c)));
  grid.appendChild(fragmento);
}

function listaHTML(items, vacio = "Sin información registrada.") {
  if (!items || items.length === 0) return `<p>${vacio}</p>`;
  return `<ul>${items.map((item) => `<li>${item}</li>`).join("")}</ul>`;
}

function abrirDetalle(id) {
  const contaminante = contaminantesActuales.find((c) => c._id === id);
  if (!contaminante) return;

  modalContenido.innerHTML = `
    <div class="modal-contenido">
      <span class="categoria-pill">${contaminante.categoria}</span>
      <h3 id="modal-titulo">${contaminante.nombre}</h3>
      <p>${contaminante.descripcion}</p>

      <div class="modal-seccion">
        <h4>Fuentes comunes en el hogar</h4>
        ${listaHTML(contaminante.fuentesComunes)}
      </div>

      <div class="modal-seccion">
        <h4>Efectos documentados en la salud</h4>
        ${listaHTML(contaminante.efectosSalud)}
      </div>

      <div class="modal-seccion">
        <h4>Medidas de mitigación recomendadas</h4>
        ${listaHTML(contaminante.medidasMitigacion)}
      </div>

      ${
        contaminante.fuenteVerificada
          ? `<p class="fuente-verificada">Fuente verificada: ${contaminante.fuenteVerificada}</p>`
          : ""
      }
    </div>
  `;

  modal.hidden = false;
  modalCerrar.focus();
}

function cerrarDetalle() {
  modal.hidden = true;
}

modalCerrar.addEventListener("click", cerrarDetalle);
modal.addEventListener("click", (e) => {
  if (e.target === modal) cerrarDetalle();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !modal.hidden) cerrarDetalle();
});

async function cargarTodos() {
  estadoCatalogo.textContent = "Cargando contaminantes…";
  try {
    const respuesta = await fetch(`${API_BASE_URL}/contaminantes`);
    const data = await respuesta.json();

    if (!data.exito) throw new Error(data.mensaje || "Error desconocido");

    renderContaminantes(data.datos);
    estadoCatalogo.textContent = `${data.total} contaminante(s) en el catálogo.`;
  } catch (error) {
    grid.innerHTML = `<p class="estado-error">No pudimos conectar con la API. Verifica que el servidor esté corriendo en ${API_BASE_URL}.</p>`;
    estadoCatalogo.textContent = "";
    console.error(error);
  }
}

async function buscarContaminantes(termino) {
  estadoCatalogo.textContent = `Buscando "${termino}"…`;
  try {
    const respuesta = await fetch(
      `${API_BASE_URL}/contaminantes/buscar?q=${encodeURIComponent(termino)}`
    );
    const data = await respuesta.json();

    if (!data.exito) throw new Error(data.mensaje || "Error desconocido");

    renderContaminantes(data.datos);
    estadoCatalogo.textContent = `${data.total} resultado(s) para "${termino}".`;
  } catch (error) {
    grid.innerHTML = `<p class="estado-error">Ocurrió un error al buscar. Intenta de nuevo en unos segundos.</p>`;
    estadoCatalogo.textContent = "";
    console.error(error);
  }
}

formBusqueda.addEventListener("submit", (e) => {
  e.preventDefault();
  const termino = inputBusqueda.value.trim();
  if (termino === "") {
    cargarTodos();
    return;
  }
  buscarContaminantes(termino);
});

btnLimpiar.addEventListener("click", () => {
  inputBusqueda.value = "";
  cargarTodos();
});


cargarTodos();
