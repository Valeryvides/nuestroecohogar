const mongoose = require("mongoose");


const contaminantSchema = new mongoose.Schema(
  {
    nombre: {
      type: String,
      required: [true, "El nombre del contaminante es obligatorio"],
      trim: true,
      unique: true,
    },
    categoria: {
      type: String,
      required: true,
      enum: [
        "Microplásticos",
        "Ftalatos",
        "Bisfenoles",
        "Residuos farmacéuticos",
        "Pesticidas",
        "PFAS",
        "Otro",
      ],
      default: "Otro",
    },
    descripcion: {
      type: String,
      required: [true, "La descripción es obligatoria"],
      trim: true,
    },
    fuentesComunes: {
      // Dónde se encuentra habitualmente en el hogar
      type: [String],
      default: [],
    },
    efectosSalud: {
      // Efectos documentados en la salud humana
      type: [String],
      default: [],
    },
    medidasMitigacion: {
      // Recomendaciones prácticas para reducir la exposición
      type: [String],
      default: [],
    },
    nivelPreocupacion: {
      // Clasificación simple para la interfaz (bajo / medio / alto)
      type: String,
      enum: ["Bajo", "Medio", "Alto"],
      default: "Medio",
    },
    fuenteVerificada: {
      // Referencia bibliográfica u organismo que respalda la información
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true, // createdAt, updatedAt
    collection: "Emergentes",
  }
);


contaminantSchema.index({ nombre: "text", descripcion: "text", categoria: "text" });

module.exports = mongoose.model("Contaminant", contaminantSchema);
