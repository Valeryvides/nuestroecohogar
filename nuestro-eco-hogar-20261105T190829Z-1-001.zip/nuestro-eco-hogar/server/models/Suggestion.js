const mongoose = require("mongoose");

/**
 * Modelo para los mensajes enviados desde el formulario de contacto /
 * sugerencias de la web. Permite a la comunidad proponer nuevos
 * contaminantes a investigar o hacer preguntas.
 */
const suggestionSchema = new mongoose.Schema(
  {
    nombre: {
      type: String,
      required: [true, "Tu nombre es obligatorio"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "Tu correo es obligatorio"],
      trim: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, "El correo no tiene un formato válido"],
    },
    tipo: {
      type: String,
      enum: ["Sugerencia de contaminante", "Duda", "Comentario general"],
      default: "Comentario general",
    },
    mensaje: {
      type: String,
      required: [true, "El mensaje no puede estar vacío"],
      trim: true,
      maxlength: 1500,
    },
    atendido: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Suggestion", suggestionSchema);
