const express = require("express");
const router = express.Router();

const { crearSugerencia, getSugerencias } = require("../controllers/contactController");

router.route("/").post(crearSugerencia).get(getSugerencias);

module.exports = router;
