const express = require("express");
const router = express.Router();

const {
  getContaminantes,
  buscarContaminantes,
  getContaminantePorId,
  crearContaminante,
} = require("../controllers/contaminantController");


router.get("/buscar", buscarContaminantes);

router.route("/").get(getContaminantes).post(crearContaminante);

router.get("/:id", getContaminantePorId);

module.exports = router;
