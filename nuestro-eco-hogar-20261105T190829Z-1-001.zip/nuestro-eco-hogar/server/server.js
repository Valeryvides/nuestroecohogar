const path = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") });

const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const contaminantRoutes = require("./routes/contaminantRoutes");
const contactRoutes = require("./routes/contactRoutes");

// Conectar a la base de datos antes de levantar el servidor
connectDB();

const app = express();


// Middlewares
app.use(
  cors({
    origin: process.env.CLIENT_ORIGIN || "*",
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Ruta de salud, útil para comprobar rápido que la API está viva
app.get("/api/health", (req, res) => {
  res.status(200).json({ exito: true, mensaje: "API Nuestro Eco-Hogar funcionando correctamente 🌱" });
});

// Rutas principales de la API
app.use("/api/contaminantes", contaminantRoutes);
app.use("/api/contacto", contactRoutes);

// Manejo de rutas no encontradas
app.use((req, res) => {
  res.status(404).json({ exito: false, mensaje: "Ruta no encontrada" });
});

// Manejador de errores genérico
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ exito: false, mensaje: "Error interno del servidor" });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
