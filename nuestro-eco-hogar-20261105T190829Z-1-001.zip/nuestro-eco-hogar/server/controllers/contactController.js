const Suggestion = require("../models/Suggestion");


const crearSugerencia = async (req, res) => {
  try {
    const { nombre, email, tipo, mensaje } = req.body;

    const nuevaSugerencia = await Suggestion.create({
      nombre,
      email,
      tipo,
      mensaje,
    });

    res.status(201).json({
      exito: true,
      mensaje: "¡Gracias! Tu mensaje fue recibido correctamente.",
      datos: nuevaSugerencia,
    });
  } catch (error) {
    res.status(400).json({
      exito: false,
      mensaje: "No se pudo enviar tu mensaje. Revisa los campos del formulario.",
      error: error.message,
    });
  }
};


const getSugerencias = async (req, res) => {
  try {
    const sugerencias = await Suggestion.find().sort({ createdAt: -1 });

    res.status(200).json({
      exito: true,
      total: sugerencias.length,
      datos: sugerencias,
    });
  } catch (error) {
    res.status(500).json({
      exito: false,
      mensaje: "Error al obtener las sugerencias",
      error: error.message,
    });
  }
};

module.exports = { crearSugerencia, getSugerencias };
