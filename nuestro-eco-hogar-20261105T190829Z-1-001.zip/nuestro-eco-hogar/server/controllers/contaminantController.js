const Contaminant = require("../models/Contaminant");


const getContaminantes = async (req, res) => {
  try {
    const { categoria } = req.query;
    const filtro = categoria ? { categoria } : {};

    const contaminantes = await Contaminant.find(filtro).sort({ nombre: 1 });

    res.status(200).json({
      exito: true,
      total: contaminantes.length,
      datos: contaminantes,
    });
  } catch (error) {
    res.status(500).json({
      exito: false,
      mensaje: "Error al obtener los contaminantes",
      error: error.message,
    });
  }
};

const buscarContaminantes = async (req, res) => {
  try {
    const { q } = req.query;

    if (!q || q.trim() === "") {
      return res.status(400).json({
        exito: false,
        mensaje: "Debes indicar un término de búsqueda con el parámetro ?q=",
      });
    }

    const regex = new RegExp(q.trim(), "i");

    const resultados = await Contaminant.find({
      $or: [{ nombre: regex }, { categoria: regex }, { descripcion: regex }],
    }).sort({ nombre: 1 });

    res.status(200).json({
      exito: true,
      total: resultados.length,
      datos: resultados,
    });
  } catch (error) {
    res.status(500).json({
      exito: false,
      mensaje: "Error al buscar contaminantes",
      error: error.message,
    });
  }
};


const getContaminantePorId = async (req, res) => {
  try {
    const contaminante = await Contaminant.findById(req.params.id);

    if (!contaminante) {
      return res.status(404).json({
        exito: false,
        mensaje: "Contaminante no encontrado",
      });
    }

    res.status(200).json({ exito: true, datos: contaminante });
  } catch (error) {
    res.status(500).json({
      exito: false,
      mensaje: "Error al obtener el contaminante",
      error: error.message,
    });
  }
};


const crearContaminante = async (req, res) => {
  try {
    const nuevoContaminante = await Contaminant.create(req.body);

    res.status(201).json({
      exito: true,
      mensaje: "Contaminante creado correctamente",
      datos: nuevoContaminante,
    });
  } catch (error) {
    res.status(400).json({
      exito: false,
      mensaje: "No se pudo crear el contaminante. Revisa los datos enviados.",
      error: error.message,
    });
  }
};

module.exports = {
  getContaminantes,
  buscarContaminantes,
  getContaminantePorId,
  crearContaminante,
};
